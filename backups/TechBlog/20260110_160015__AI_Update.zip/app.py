import os
from flask import Flask, render_template, request, url_for

app = Flask(__name__)

# --- Dummy Data --- #
CATEGORIES = ['Python', 'Web Dev', 'AI', 'Cloud', 'Data Science']
ABOUT_CONTENT = """Welcome to the TechBlog! We aim to provide insightful articles on cutting-edge technologies, 
programming, and development. Our mission is to empower developers and tech enthusiasts with knowledge 
and foster a community where learning and innovation thrive.
We cover a wide range of topics, from fundamental programming concepts to advanced machine learning algorithms,
cloud infrastructure, and modern web development practices. Stay tuned for tutorials, in-depth analyses, and industry news!
"""
CONTACT_DETAILS = """You can reach us via email at <a href="mailto:info@techblog.com">info@techblog.com</a>. 
Follow us on social media for updates:
<ul>
    <li><a href="#">Twitter</a></li>
    <li><a href="#">LinkedIn</a></li>
    <li><a href="#">GitHub</a></li>
</ul>
We look forward to hearing from you!
"""
POSTS_BY_CATEGORY = {
    'Python': [
        {'title': 'Getting Started with Flask', 'content': 'Learn Flask basics with this comprehensive guide to build your first web application.'},
        {'title': 'Python Decorators Explained', 'content': 'Understanding decorators and how to use them effectively for cleaner and more powerful code.'},
        {'title': 'Asynchronous Python with Asyncio', 'content': 'Dive into asynchronous programming in Python using the asyncio library for concurrent code.'}
    ],
    'Web Dev': [
        {'title': 'Modern CSS Techniques', 'content': 'Master Flexbox and Grid for responsive web design and complex layouts.'},
        {'title': 'JavaScript ES6 Features', 'content': 'Explore new features in ECMAScript 2015 and beyond that enhance modern JavaScript development.'},
        {'title': 'Building RESTful APIs with Node.js', 'content': 'A guide to creating robust RESTful APIs using Node.js and Express.js.'}
    ],
    'AI': [
        {'title': 'Introduction to Machine Learning', 'content': 'Basic ML concepts and algorithms for beginners, covering supervised and unsupervised learning.'},
        {'title': 'Deep Learning with TensorFlow', 'content': 'Building neural networks and understanding deep learning concepts with TensorFlow and Keras.'},
        {'title': 'Natural Language Processing Basics', 'content': 'An introduction to NLP, covering tokenization, stemming, and sentiment analysis.'}
    ],
    'Cloud': [
        {'title': 'Deploying Flask on AWS EC2', 'content': 'How to deploy your Flask app to an Amazon EC2 instance step-by-step.'},
        {'title': 'Understanding Docker Containers', 'content': 'Containerization basics and Docker commands for efficient application deployment.'},
        {'title': 'Serverless Functions with AWS Lambda', 'content': 'Explore how to build and deploy serverless applications using AWS Lambda.'}
    ],
    'Data Science': [
        {'title': 'Pandas for Data Analysis', 'content': 'Using pandas DataFrames for efficient data manipulation and analysis in Python.'},
        {'title': 'Matplotlib for Data Visualization', 'content': 'Creating informative plots and charts with Matplotlib for data exploration.'},
        {'title': 'Introduction to SQL for Data Scientists', 'content': 'Learn the fundamental SQL commands necessary for data retrieval and manipulation.'}
    ],
}

@app.route('/')
def home():
    recent_posts = []
    # Take one post from each category for the home page for variety
    for category_name in CATEGORIES:
        if category_name in POSTS_BY_CATEGORY and POSTS_BY_CATEGORY[category_name]:
            recent_posts.append(POSTS_BY_CATEGORY[category_name][0])
    return render_template('index.html',
                           current_page='home',
                           title='Home - TechBlog',
                           categories=CATEGORIES,
                           posts=recent_posts)

@app.route('/about')
def about():
    return render_template('index.html',
                           current_page='about',
                           title='About Us - TechBlog',
                           categories=CATEGORIES,
                           about_content=ABOUT_CONTENT)

@app.route('/contact')
def contact():
    return render_template('index.html',
                           current_page='contact',
                           title='Contact Us - TechBlog',
                           categories=CATEGORIES,
                           contact_details=CONTACT_DETAILS)

@app.route('/category/<string:name>')
def category(name):
    posts = POSTS_BY_CATEGORY.get(name, [])
    return render_template('index.html',
                           current_page='category',
                           title=f'{name} - TechBlog',
                           categories=CATEGORIES,
                           category_name=name,
                           posts=posts)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)