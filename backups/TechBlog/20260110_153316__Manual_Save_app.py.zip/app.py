from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/articles.html')
def articles():
    # The category filtering is handled by JavaScript in articles.html,
    # so we just need to render the page.
    # The 'request' object (imported above) would be used if server-side filtering was desired.
    return render_template('articles.html')

@app.route('/article-detail.html')
def article_detail():
    return render_template('article-detail.html')

if __name__ == '__main__':
    app.run(debug=True)