from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

# Featured route - redirects to articles page with 'featured' category parameter
@app.route('/featured')
def featured():
    return redirect(url_for('articles', category='featured'))

# Main articles page, can be filtered by category via query parameter
@app.route('/articles.html')
def articles():
    # Retrieve category from query parameter, e.g., /articles.html?category=Gaming
    selected_category = request.args.get('category')
    # The current comment says filtering is JS-handled in articles.html.
    # We pass the category to the template if the JS needs to read it from the server-rendered context.
    # Otherwise, JS can directly read the URL query parameter.
    return render_template('articles.html', selected_category=selected_category)

@app.route('/article-detail.html')
def article_detail():
    return render_template('article-detail.html')

# About page route
@app.route('/about')
def about():
    # Assuming an about.html template exists or will be created later
    return render_template('about.html')

# Contact page route
@app.route('/contact')
def contact():
    # Assuming a contact.html template exists or will be created later
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)