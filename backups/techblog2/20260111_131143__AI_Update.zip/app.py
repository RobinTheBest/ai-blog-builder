import os
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    categories = ['Python', 'Web Development', 'Data Science', 'DevOps', 'Cloud']
    return render_template('index.html', categories=categories)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    # In a real app, you'd handle form submission here
    if request.method == 'POST':
        # Process form data, e.g., send email, save to DB
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        print(f"Contact Form Submission:\nName: {name}\nEmail: {email}\nSubject: {subject}\nMessage: {message}")
        # For simplicity, just re-render the page with a success message
        return render_template('contact.html', success=True)
    return render_template('contact.html', success=False)

@app.route('/category/<category_name>')
def category(category_name):
    # In a real app, you would fetch posts related to this category
    # For now, we'll just display the category name
    return render_template('category.html', category_name=category_name.replace('-', ' ').title())

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)