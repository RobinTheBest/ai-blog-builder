import os
from flask import Flask, render_template, abort, url_for

app = Flask(__name__)

# Dummy data for articles
articles = [
    {
        "id": "intro-ai-future",
        "title": "Unlocking the Future: An Introduction to AI",
        "description": "Explore the foundational concepts of Artificial Intelligence and its profound impact on our world.",
        "content": """
            <p>Artificial Intelligence (AI) is rapidly transforming industries, societies, and our daily lives. From predictive algorithms that power your favorite streaming services to advanced robotics in manufacturing, AI is at the forefront of innovation.</p>
            <p>At its core, AI refers to the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions. This broad definition encompasses machine learning, deep learning, natural language processing, and computer vision.</p>
            <p>The potential of AI is immense, promising breakthroughs in medicine, climate change, and space exploration. However, it also presents challenges related to ethics, privacy, and job displacement. Understanding AI is crucial for navigating the future it is shaping.</p>
            <h3>Key Branches of AI:</h3>
            <ul>
                <li><strong>Machine Learning:</strong> Algorithms that allow systems to learn from data without explicit programming.</li>
                <li><strong>Deep Learning:</strong> A subset of machine learning using neural networks with many layers.</li>
                <li><strong>Natural Language Processing (NLP):</strong> Enables computers to understand, interpret, and generate human language.</li>
                <li><strong>Computer Vision:</strong> Allows computers to \"see\" and interpret visual information from the world.</li>
            </ul>
            <p>As AI continues to evolve, its integration into various sectors will only deepen, making it a pivotal technology for the 21st century.</p>
        """
    },
    {
        "id": "blockchain-beyond-crypto",
        "title": "Blockchain Beyond Crypto: Reshaping Industries",
        "description": "Discover how blockchain technology is extending its reach far beyond cryptocurrencies.",
        "content": """
            <p>When most people hear \"blockchain,\" their minds immediately jump to cryptocurrencies like Bitcoin. While blockchain is the underlying technology for digital currencies, its applications extend far beyond finance, promising to revolutionize supply chains, healthcare, intellectual property, and more.</p>
            <p>A blockchain is a decentralized, distributed ledger that records transactions in a secure and immutable way. Each \"block\" contains a timestamped batch of valid transactions, and once recorded, the data in any given block cannot be altered retroactively without the alteration of all subsequent blocks and the consensus of the network.</p>
            <h3>Transformative Applications:</h3>
            <ul>
                <li><strong>Supply Chain Management:</strong> Enhancing transparency and traceability of goods from origin to consumer.</li>
                <li><strong>Healthcare:</strong> Securely managing patient records and ensuring data integrity.</li>
                <li><strong>Voting Systems:</strong> Creating tamper-proof and transparent election processes.</li>
                <li><strong>Intellectual Property:</strong> Protecting copyrights and verifying ownership of digital assets.</li>
            </ul>
            <p>The core principles of decentralization, transparency, and immutability make blockchain a powerful tool for building trust in digital interactions, making it a foundational technology for a more secure and efficient digital future.</p>
        """
    },
    {
        "id": "quantum-computing-demystified",
        "title": "Quantum Computing Demystified: The Next Frontier",
        "description": "Unravel the mysteries of quantum computing and its mind-bending potential.",
        "content": """
            <p>Quantum computing represents a paradigm shift from classical computing, leveraging the principles of quantum mechanics to solve complex problems intractable for even the most powerful supercomputers today. Instead of bits, which represent information as either 0 or 1, quantum computers use \"qubits\" which can represent 0, 1, or both simultaneously through superposition.</p>
            <p>This allows quantum computers to process vast amounts of information in parallel, leading to exponential speedups for certain types of computations. While still in its nascent stages, quantum computing holds the promise to revolutionize fields like drug discovery, material science, financial modeling, and cryptography.</p>
            <h3>Core Concepts:</h3>
            <ul>
                <li><strong>Superposition:</strong> A qubit can exist in multiple states at once.</li>
                <li><strong>Entanglement:</strong> Two or more qubits become linked, where the state of one instantly affects the state of the other, regardless of distance.</li>
                <li><strong>Quantum Tunneling:</strong> Particles can pass through energy barriers that classical physics would forbid.</li>
            </ul>
            <p>The challenges in building stable and scalable quantum computers are immense, but ongoing research and development suggest a future where quantum machines could tackle humanity's most pressing scientific and engineering challenges.</p>
        """
    }
]


@app.route('/')
def home():
    return render_template('index.html', articles=articles)

@app.route('/article/<id>')
def article(id):
    article = next((a for a in articles if a['id'] == id), None)
    if article is None:
        abort(404)
    return render_template('article.html', article=article)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/category')
def category():
    return render_template('category.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)