import os
from flask import Flask, render_template, request
import self

app = Flask(__name__)

# Dummy data for categories and blog posts
# In a real app, this would come from a database
categories = ["Match Reports", "Player Profiles", "Tactics & Analysis", "Transfer Rumours"]

blog_posts = [
    {"id": 1, "title": "Arsenal's Title Challenge: A Deep Dive", "category": "Match Reports", "content": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", "author": "ChatGPT", "date": "2023-10-26"},
    {"id": 2, "title": "Messi vs Ronaldo: The Eternal Debate", "category": "Player Profiles", "content": "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "author": "ChatGPT", "date": "2023-10-25"},
    {"id": 3, "title": "The Art of Gegenpressing: Klopp's Masterclass", "category": "Tactics & Analysis", "content": "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.", "author": "ChatGPT", "date": "2023-10-24"},
    {"id": 4, "title": "Mbappe to Real Madrid: What's the Latest?", "category": "Transfer Rumours", "content": "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.", "author": "ChatGPT", "date": "2023-10-23"},
    {"id": 5, "title": "Premier League Season Review: Surprises and Disappointments", "category": "Match Reports", "content": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.", "author": "ChatGPT", "date": "2023-10-22"},
]

@app.route('/')
def home():
    featured_posts = blog_posts[:3] # Display a few featured posts on the homepage
    return render_template('index.html', categories=categories, posts=featured_posts)

@app.route('/about')
def about():
    return render_template('about.html', categories=categories)

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        # In a real app, you would process this data (e.g., save to DB, send email)
        print(f"Contact form submitted by {name} ({email}): {message}")
        return render_template('contact.html', categories=categories, success_message="Thanks for your message! We'll get back to you soon.")
    return render_template('contact.html', categories=categories)

@app.route('/category/<name>')
def category(name):
    # Filter posts by category
    category_posts = [post for post in blog_posts if post['category'] == name]
    return render_template('category.html', categories=categories, current_category=name, posts=category_posts)

# Error handling for 404
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', categories=categories), 404

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)