import os
from flask import Flask, render_template

app = Flask(__name__)

# Dummy data for articles and categories
articles_data = [
    {"id": 1, "title": "Understanding Python Decorators", "category": "Python", "author": "Alice", "date": "2023-01-15", "content": "Decorators are a very powerful and useful tool in Python. They allow you to modify or enhance a function or method without changing its source code.", "slug": "understanding-python-decorators"},
    {"id": 2, "title": "Flask vs Django: Which one to choose?", "category": "Web Dev", "author": "Bob", "date": "2023-02-01", "content": "Choosing between Flask and Django often comes down to the project's size, complexity, and the developer's preference for 'batteries included' vs. minimalism.", "slug": "flask-vs-django"},
    {"id": 3, "title": "Introduction to Machine Learning with Scikit-learn", "category": "AI/ML", "author": "Charlie", "date": "2023-02-10", "content": "Scikit-learn is a free software machine learning library for the Python programming language. It features various classification, regression and clustering algorithms.", "slug": "intro-to-ml-scikit-learn"},
    {"id": 4, "title": "Getting Started with Docker for Developers", "category": "DevOps", "author": "Alice", "date": "2023-03-01", "content": "Docker allows you to package an application with all of its dependencies into a standardized unit for software development. This guide covers the basics.", "slug": "getting-started-docker"},
    {"id": 5, "title": "RESTful APIs in Flask", "category": "Python", "author": "Bob", "date": "2023-03-10", "content": "Building RESTful APIs is a common task for web developers. Flask makes it easy to create powerful APIs with minimal code.", "slug": "restful-apis-flask"}
]

categories_data = sorted(list(set(article["category"] for article in articles_data)))


@app.route('/')
def home():
    featured_articles = articles_data[:3] # Show first 3 as featured
    return render_template('index.html', articles=featured_articles, categories=categories_data)

@app.route('/about')
def about():
    return render_template('about.html', categories=categories_data)

@app.route('/contact')
def contact():
    return render_template('contact.html', categories=categories_data)

@app.route('/articles')
@app.route('/articles/<category>')
def articles(category=None):
    if category:
        filtered_articles = [article for article in articles_data if article["category"] == category]
        page_title = f"Articles in {category}"
    else:
        filtered_articles = articles_data
        page_title = "All Articles"
    return render_template('articles.html', articles=filtered_articles, categories=categories_data, page_title=page_title)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)