import os
from flask import Flask, render_template, request

app = Flask(__name__)

# Sample blog posts (in-memory storage for simplicity)
posts = [
    {
        'id': 1,
        'title': 'Delicious Pasta Recipe',
        'content': 'This is a super easy and delicious pasta recipe you can make in under 30 minutes. Perfect for a weeknight meal!',
        'full_content': 'This is a super easy and delicious pasta recipe you can make in under 30 minutes. Perfect for a weeknight meal! Ingredients: pasta, tomatoes, garlic, basil, olive oil. Instructions: Boil pasta, sauté garlic, add tomatoes, combine with pasta and basil. Serve hot with grated Parmesan.'
    },
    {
        'id': 2,
        'title': 'Baking Perfect Sourdough',
        'content': 'Sourdough bread can be intimidating, but with these tips, you\u0027ll be baking like a pro in no time.',
        'full_content': 'Sourdough bread can be intimidating, but with these tips, you\u0027ll be baking like a pro in no time. Key steps: active starter, proper kneading, long fermentation, and high heat baking. Don\u0027t forget to use good quality flour! Patience is key for the perfect crust and crumb.'
    },
    {
        'id': 3,
        'title': 'My Favorite Vegan Smoothies',
        'content': 'Looking for healthy and tasty vegan smoothie recipes? Here are my top three picks that are packed with nutrients.',
        'full_content': 'Looking for healthy and tasty vegan smoothie recipes? Here are my top three picks that are packed with nutrients. Try: Green Detox (spinach, banana, almond milk), Berry Boost (mixed berries, chia seeds, coconut water), Tropical Paradise (mango, pineapple, orange juice). Customize with your favorite seeds or protein powder.'
    }
]

@app.route('/')
def home():
    return render_template('index.html', posts=posts)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5005))
    app.run(debug=True, host='0.0.0.0', port=port)